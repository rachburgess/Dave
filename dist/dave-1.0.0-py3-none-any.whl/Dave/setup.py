#!/usr/bin/env python3
"""Setup script for Dave Python package."""

import os
from setuptools import setup, find_packages

# Auto-generate __init__.py
dave_dir = os.path.join(os.path.dirname(__file__), 'Dave')
if not os.path.exists(dave_dir):
    os.makedirs(dave_dir)

with open(os.path.join('Dave', '__init__.py'), 'w') as f:
    f.write('''"""
Dave - Cross-platform Python Application

This package provides platform-specific functionality for Dave.

Supports Windows, Linux, macOS, and Android platforms.
"""

import sys

VERSION = "1.0.0"


def get_platform() -> str:
    """Get the current platform."""
    mapping = {
        'win32': 'windows',
        'darwin': 'macos',
        'linux': 'linux',
        'android': 'android'
    }
    
    return mapping.get(sys.platform, f"unknown ({sys.platform})")


__all__ = ['get_platform', 'VERSION']
''')

# Add MANIFEST.in to include all .py files in Dave/
manifest_path = os.path.join(os.path.dirname(__file__), 'MANIFEST.in')
with open(manifest_path, 'w') as f:
    f.write(
        "include Dave/*.py\n"
        "include *.md\n"
        "include *.txt\n"
        "include *.toml\n"
        "include *.cfg\n"
    )

setup(
    name='dave',
    version='1.0.0',
    description='Cross-platform Python application for various operating systems',
    url='https://github.com/rachburgess/Dave',
    project_urls={
        'Bug Tracker': 'https://github.com/rachburgess/Dave/issues'
    },
    license='MIT',
    python_requires='>=3.7',
)
