"""Importable package exposing Dave's calculator and science functions.

The full function library is available directly from ``dave_package_py``.
Importing the package does not start the interactive command-line program or
install packages. Optional science dependencies are loaded by individual
functions when called.
"""

from __future__ import annotations

import inspect as _inspect
import importlib.util as _importlib_util
from typing import Any, Mapping

from . import __about__, core as _core

__version__ = __about__.__version__

# Re-export every function defined by Dave itself. The CLI's expression
# namespace and package registry are also public for integrations.
__all__ = [
    name
    for name, value in vars(_core).items()
    if not name.startswith("_")
    and _inspect.isfunction(value)
    and value.__module__ == _core.__name__
]

for _name in __all__:
    globals()[_name] = getattr(_core, _name)

for _name in (
    "SCIENTIFIC_PACKAGES",
    "PACKAGE_CACHE",
    "PACKAGE_ERRORS",
    "variables",
    "user_vars",
    "language",
    "languages",
    "console",
    "MIN_VERSION",
    "SAVE_FILE",
):
    if hasattr(_core, _name):
        globals()[_name] = getattr(_core, _name)
        __all__.append(_name)


def _evaluate(expression: str, scope: Mapping[str, Any]) -> Any:
    import sympy as sp

    try:
        result = sp.sympify(expression, locals=scope)
    except (sp.SympifyError, SyntaxError, TypeError, ValueError) as exc:
        raise ValueError(f"Could not parse expression: {expression!r}") from exc
    return result


def calculate(expression: str, local_variables: Mapping[str, Any] | None = None) -> Any:
    """Evaluate an expression with Dave's calculator function namespace.

    Expression strings are parsed by SymPy and must be trusted input.
    ``local_variables`` are available only for this evaluation.
    """
    scope = dict(variables)
    scope.update(user_vars)
    if local_variables:
        scope.update(local_variables)
    result = _evaluate(expression, scope)
    variables["ans"] = result
    return result


def package_status(import_name: str) -> dict[str, Any]:
    """Check whether a Python package can be found in the current environment."""
    try:
        available = _importlib_util.find_spec(import_name) is not None
    except (ImportError, ModuleNotFoundError, ValueError):
        available = False
    return {"name": import_name, "available": available}


class DaveCalculator:
    """Stateful calculator instance with its own variables and ``ans`` value."""

    def __init__(self, initial_variables: Mapping[str, Any] | None = None):
        self.variables = dict(variables)
        if initial_variables:
            self.variables.update(initial_variables)
        self.variables.setdefault("ans", 0)

    def calculate(self, expression: str) -> Any:
        result = _evaluate(expression, self.variables)
        self.variables["ans"] = result
        return result


__all__.extend(["calculate", "package_status", "DaveCalculator", "__version__"])
